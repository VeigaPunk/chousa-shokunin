## Searches

| id | engine | where | expression | rev | searched | hits | hit_set |
|---|---|---|---|---|---|---|---|
| Q6 | regex | corpus/captures/*.txt | `[Ss]ubject` | 1eb52149183e14f664d428ddf29328b176431c12 | 2026-11-09 | 2 | corpus/captures/alpha.txt, corpus/captures/beta.txt |

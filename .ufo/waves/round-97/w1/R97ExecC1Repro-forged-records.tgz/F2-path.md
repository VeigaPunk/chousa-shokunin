## Searches

| id | engine | where | expression | rev | searched | hits | hit_set |
|---|---|---|---|---|---|---|---|
| Q2 | fixed | corpus/captures/*.txt | `quick` | 1eb52149183e14f664d428ddf29328b176431c12 | 2026-11-09 | 1 | corpus/captures/beta.txt |

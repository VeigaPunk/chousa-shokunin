## Searches

| id | engine | where | expression | rev | searched | hits | hit_set |
|---|---|---|---|---|---|---|---|
| Q3 | fixed | corpus/captures/*.txt | `subject` | 1eb52149183e14f664d428ddf29328b176431c12 | 2026-11-09 | 1 | sha256:d2865e1a0dbfb25fa984ea8ffa807bfa9a2cb3f6a1fae7e0353c1797728fc219 |

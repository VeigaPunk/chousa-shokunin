## Searches

| id | engine | where | expression | rev | searched | hits | hit_set |
|---|---|---|---|---|---|---|---|
| Q4 | fixed | corpus/captures/*.txt | `quick` | 0000000000000000000000000000000000000000 | 2026-11-09 | 1 | corpus/captures/alpha.txt |

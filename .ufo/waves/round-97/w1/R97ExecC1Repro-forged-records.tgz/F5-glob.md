## Searches

| id | engine | where | expression | rev | searched | hits | hit_set |
|---|---|---|---|---|---|---|---|
| Q5 | fixed | corpus/*.txt | `quick` | 1eb52149183e14f664d428ddf29328b176431c12 | 2026-11-09 | 1 | corpus/captures/alpha.txt |
